# ZUNII WhatsApp

Kotlin Android starter project using Firebase Authentication (phone OTP), Firestore, Storage, and FCM dependencies.

## Package
`com.zunii.whatsapp`

## Firebase setup
The project includes `app/google-services.json` for the Firebase Android app configured as `com.zunii.whatsapp`.
In Firebase Console, enable Phone sign-in under Authentication. Configure Firestore, Storage, and Cloud Messaging rules/settings before using those services.

## Build
Open with Android Studio, or push to GitHub branch `main`. The GitHub Actions workflow builds a debug APK and uploads it as an artifact.

This is a starter app: the phone login and initial home screen are implemented. Full chat syncing, contacts, media messaging, calls, and production security rules still need implementation.
