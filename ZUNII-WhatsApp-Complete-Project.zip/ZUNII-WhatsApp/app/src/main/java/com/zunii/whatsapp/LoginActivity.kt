package com.zunii.whatsapp

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import java.util.concurrent.TimeUnit

class LoginActivity : Activity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var phone: EditText
    private lateinit var otp: EditText
    private lateinit var status: TextView
    private var verificationId: String? = null
    private val bg = Color.rgb(3, 20, 15)
    private val green = Color.rgb(0, 190, 110)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = FirebaseAuth.getInstance()
        if (auth.currentUser != null) {
            openHome()
            return
        }
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(25.dp(), 25.dp(), 25.dp(), 25.dp())
            setBackgroundColor(bg)
        }
        root.addView(TextView(this).apply {
            text = "ZUNII"
            textSize = 38f
            gravity = Gravity.CENTER
            setTextColor(green)
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "WhatsApp"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(white)
        })
        phone = field("+923001234567", false)
        otp = field("6-digit SMS code", true).apply { visibility = View.GONE }
        status = TextView(this).apply {
            text = "Enter your phone number with country code."
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            textSize = 13f
        }
        val send = Button(this).apply { text = "SEND OTP" }
        val verify = Button(this).apply {
            text = "VERIFY OTP"
            visibility = View.GONE
        }
        root.addView(phone, params())
        root.addView(send, params())
        root.addView(otp, params())
        root.addView(verify, params())
        root.addView(status, params())

        send.setOnClickListener {
            val number = phone.text.toString().trim()
            if (!number.matches(Regex("^\\+[1-9][0-9]{7,14}$"))) {
                status.text = "Use international format, e.g. +923001234567"
            } else {
                sendOtp(number, send, verify)
            }
        }
        verify.setOnClickListener {
            val code = otp.text.toString().trim()
            val id = verificationId
            if (id == null || code.length != 6) {
                status.text = "Enter the 6-digit code."
            } else {
                signIn(PhoneAuthProvider.getCredential(id, code))
            }
        }
        setContentView(root)
    }

    private fun sendOtp(number: String, send: Button, verify: Button) {
        status.text = "Sending verification code..."
        send.isEnabled = false
        val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                signIn(credential)
            }
            override fun onVerificationFailed(e: FirebaseException) {
                status.text = "Verification failed: ${e.localizedMessage}"
                send.isEnabled = true
            }
            override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                verificationId = id
                status.text = "Code sent. Check your SMS."
                otp.visibility = View.VISIBLE
                verify.visibility = View.VISIBLE
                send.isEnabled = true
            }
        }
        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(number)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(this)
            .setCallbacks(callbacks)
            .build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    private fun signIn(credential: PhoneAuthCredential) {
        status.text = "Checking code..."
        auth.signInWithCredential(credential).addOnCompleteListener(this) { task ->
            if (task.isSuccessful) {
                Toast.makeText(this, "Welcome to ZUNII WhatsApp", Toast.LENGTH_LONG).show()
                openHome()
            } else {
                status.text = "Login failed: ${task.exception?.localizedMessage}"
            }
        }
    }

    private fun openHome() {
        startActivity(android.content.Intent(this, MainActivity::class.java))
        finish()
    }

    private fun field(hintText: String, numeric: Boolean) = EditText(this).apply {
        hint = hintText
        textSize = 16f
        setSingleLine(true)
        setTextColor(white)
        setHintTextColor(Color.GRAY)
        setPadding(16.dp(), 13.dp(), 16.dp(), 13.dp())
        background = GradientDrawable().apply {
            setColor(Color.rgb(12, 43, 32))
            cornerRadius = 16.dp().toFloat()
        }
        if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER
        else inputType = android.text.InputType.TYPE_CLASS_PHONE
    }

    private fun params() = LinearLayout.LayoutParams(-1, -2).apply {
        setMargins(0, 9.dp(), 0, 9.dp())
    }
    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()
}
