package com.zunii.whatsapp

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.firebase.auth.FirebaseAuth

class MainActivity : Activity() {
    private val bg = Color.rgb(3, 20, 15)
    private val green = Color.rgb(0, 190, 110)
    private val card = Color.rgb(12, 43, 32)
    private val muted = Color.rgb(160, 185, 172)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (FirebaseAuth.getInstance().currentUser == null) {
            startActivity(android.content.Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18.dp(), 18.dp(), 18.dp(), 12.dp())
            setBackgroundColor(bg)
        }
        val header = TextView(this).apply {
            text = "ZUNII WhatsApp"
            textSize = 27f
            setTextColor(green)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(header)
        root.addView(TextView(this).apply {
            text = "Stay connected. Stay together."
            textSize = 14f
            setTextColor(muted)
            setPadding(0, 5.dp(), 0, 22.dp())
        })
        root.addView(TextView(this).apply {
            text = "RECENT CHATS"
            textSize = 12f
            letterSpacing = .12f
            setTextColor(green)
            typeface = Typeface.DEFAULT_BOLD
        })

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val items = listOf(
            "Welcome to ZUNII" to "Your account is connected.",
            "Messages" to "Your conversations will appear here.",
            "Friends" to "Start connecting with people."
        )
        items.forEach { (name, preview) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16.dp(), 15.dp(), 16.dp(), 15.dp())
                background = rounded(card, 18)
                elevation = 4.dp().toFloat()
            }
            row.addView(TextView(this).apply {
                text = name
                textSize = 16f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
            })
            row.addView(TextView(this).apply {
                text = preview
                textSize = 13f
                setTextColor(muted)
                setPadding(0, 5.dp(), 0, 0)
            })
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = 12.dp()
            })
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(TextView(this).apply {
            text = "Chats       Updates       Calls       Settings"
            gravity = Gravity.CENTER
            textSize = 13f
            setTextColor(green)
            setPadding(8.dp(), 16.dp(), 8.dp(), 12.dp())
            background = rounded(card, 18)
        })
        setContentView(root)
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.dp().toFloat()
    }
    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()
}
